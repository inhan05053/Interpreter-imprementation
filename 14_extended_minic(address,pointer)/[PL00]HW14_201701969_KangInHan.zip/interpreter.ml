module F = Format

(* practice & homework *)
let rec interp_e (e : Ast.expr) ((env, mem) : Env.t * Mem.t) : Mem.value = 
	match e with
        	| Num i -> Mem.NumV i
        	| Bool i -> Mem.BoolV i
        	| Var i -> (Mem.find (Env.find i env) mem)
                | Ref i -> Mem.AddressV (Env.find i env)
                | Deref i ->  let k = Mem.find (Env.find i env) mem in
                        begin
                                match k with 
                                | Mem.AddressV a -> Mem.find a mem
                                | _ -> failwith (F.asprintf "Not a memory address: %a " Ast.pp_e e)
                        end
        	| Add (exp1,exp2) -> let expr1 = interp_e exp1 (env,mem) in
                                let expr2 = interp_e exp2 (env,mem) in
                                begin
                                match expr1,expr2 with
                                | (Mem.NumV e1, Mem.NumV e2) -> Mem.NumV (e1 + e2)
                                | _,_ -> failwith (Format.asprintf "Invalid addition: %a + %a" Ast.pp_e exp1 Ast.pp_e exp2)
                                end
        	| Sub (exp1,exp2) -> let expr1 = interp_e exp1 (env,mem) in
                                let expr2 = interp_e exp2 (env,mem) in
                                begin
                                match expr1,expr2 with
                                | (Mem.NumV e1, Mem.NumV e2) -> Mem.NumV (e1 - e2)
                                | _,_ -> failwith (Format.asprintf "Invalid subtraction: %a - %a" Ast.pp_e exp1 Ast.pp_e exp2)
                                end
        	| Lt (exp1,exp2) -> begin
                                match (interp_e exp1 (env,mem)), (interp_e exp2 (env,mem)) with
                                | Mem.NumV a, Mem.NumV b -> if a < b then Mem.BoolV true else Mem.BoolV false
                                | _,_ -> failwith (Format.asprintf "Invalid less-than: %a, %a" Ast.pp_e exp1 Ast.pp_e exp2)
                                end

        	|Gt (exp1,exp2) -> begin
                                match (interp_e exp1 (env,mem)), (interp_e exp2 (env,mem)) with
                                |Mem.NumV a, Mem.NumV b -> if a > b then Mem.BoolV true else Mem.BoolV false
                                | _,_ -> failwith (Format.asprintf "Invalid greater-than: %a, %a" Ast.pp_e exp1 Ast.pp_e exp2)
        		        end
        	|Eq (exp1,exp2) -> begin
                                match (interp_e exp1 (env,mem)), (interp_e exp2 (env,mem))  with
                                |Mem.NumV a ,Mem.NumV b -> if a = b then Mem.BoolV true else Mem.BoolV false
                                | _,_ -> failwith (Format.asprintf "Invalid equal-to: %a, %a" Ast.pp_e exp1 Ast.pp_e exp2)
        		        end
        	|And (exp1,exp2) -> begin
                                match (interp_e exp1 (env,mem)), (interp_e exp2 (env,mem)) with
                                |Mem.BoolV a, Mem.BoolV b -> if (a = true && b = true) then Mem.BoolV true else Mem.BoolV false
                                | _,_ -> failwith (Format.asprintf "Invalid logical-and: %a, %a" Ast.pp_e exp1 Ast.pp_e exp2)
                             end
        	|Or (exp1,exp2) -> begin
                                match (interp_e exp1 (env,mem)), (interp_e exp2 (env,mem)) with
                                |Mem.BoolV a ,Mem.BoolV b -> if (a = false && b = false) then Mem.BoolV false else Mem.BoolV true
                                | _,_ -> failwith (Format.asprintf "Invalid logical-or: %a, %a" Ast.pp_e exp1 Ast.pp_e exp2)
        		        end
 
(* practice & homework *)
let rec interp_s (stmt : Ast.stmt) ((env, mem) : Env.t * Mem.t) : Env.t * Mem.t =
	match stmt with
                | IfStmt (e,true_stmts,false_stmts_opt) ->
                	begin
                        	match false_stmts_opt with
                        	| None-> if interp_e e (env, mem) = BoolV true then 
                                		begin
                                        		let rec func stmts (env, mem) =
                                                		match stmts with
                                                		|h::t -> func t (interp_s h (env, mem))
                                                		|[] -> (env, mem)
                                        		in
                                        		func true_stmts (env, mem)
                                		end
                                	else if interp_e e (env, mem) = BoolV false then (env, mem)
                                	else failwith (F.asprintf "Not a boolean: %a " Ast.pp_e e)
                        	| Some false_stmts_opt ->  if interp_e e (env, mem) = BoolV true then
                               		begin
                                       		let rec func stmts (env, mem) =
                                              			match stmts with
                                              			|h::t -> func t (interp_s h (env, mem))
                                              			|[] -> (env, mem)
                                       		in
                                       		func true_stmts (env, mem)
                               		end
                        	else if interp_e e (env, mem) = BoolV false then
                               		begin
                                       		let rec func stmts (env, mem) =
                                              			match stmts with
                                              			|h::t -> func t (interp_s h (env, mem))
                                              			|[] -> (env, mem)
                                       		in
                                       		func false_stmts_opt (env, mem)
                               		end
                        	else failwith (F.asprintf "Not a boolean: %a " Ast.pp_e e)
        		end
                
                | WhileStmt (exp,stmtlist) -> begin 
                        match interp_e exp (env, mem) with
                        | BoolV true -> begin 
                                let rec func stmts (env,mem) =
                                match stmts with
                                | (h::t) -> func t (interp_s h (env,mem))
                                | [] -> (env,mem)
                                in
                                func stmtlist (env,mem)
                                end
                        | BoolV false -> (env, mem)
                        | _ ->  failwith (F.asprintf "Not a boolean: %a " Ast.pp_e exp)
                end
		| VarDeclStmt str -> if Env.mem str env = true
                                	then failwith (F.asprintf "%s is already delared." str)
                        	else (Env.insert str (Env.new_address()) env),mem 
                	| StoreStmt (exp1,exp2) ->
                                let e1 = interp_e exp1 (env,mem) in
                                match e1 with
                                |AddressV add ->  let e2 = interp_e exp2 (env,mem) in
                                        env,(Mem.insert add e2 mem)
                                | _ -> failwith (Format.asprintf "Not a memory address : %a" Ast.pp_e exp1)

(* practice & homework *)
let interp (p : Ast.program) : Env.t * Mem.t = 
        match p with
        |Program stmtlist ->
                        begin
                        let rec interp2 stmt (env,mem) =                          
                                        match stmt with
                                        | h::t -> (interp2 t (interp_s h (env,mem)))
                                        | [] -> (env,mem)
                        in
                        interp2 stmtlist (Env.empty,Mem.empty)
                        end


