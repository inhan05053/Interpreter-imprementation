module F = Format

let rec interp_e (fenv : FEnv.t) (s : Store.t) (e : Ast.expr) : int = 
        match e with     
        |Num num -> num  
        |Add (h,t) -> (interp_e fenv s h) + (interp_e fenv s t)
        |Sub (h,t) -> (interp_e fenv s h) - (interp_e fenv s t)
        |Id h1 -> Store.find h1 s
        |LetIn (v1,v2,v3) -> (interp_e fenv (Store.insert v1 (interp_e fenv s v2) s) v3)
        |FCall (v4,v5) ->
                        let qw = s in
                        let k = FEnv.find v4 fenv in
                        let rec q w v qw =
                                match w, v with
                                |(((a_h::a_t),b),(v_h::v_t)) -> let e = (interp_e fenv qw v_h) in
                                let new_k = a_t,b in
                                let qw = (Store.insert a_h e qw) in         
                                (q new_k v_t qw)
                                | ((_,b),_) -> (interp_e fenv qw b)
                        in
                        q k v5 qw
        
        
        
let interp_d (fenv : FEnv.t) (fd : Ast.fundef) : FEnv.t =
	(* write your code *)
        
        match fd with
        | FDef (str1,str2,exp) ->
                        let fenv = (FEnv.insert str1 str2 exp fenv) in
                        fenv                        
                        
let interp (p : Ast.f1vae) : int = 
        match p with
        | Prog(fund,expr) ->
                        let rec f fnd wjwkd=
                                match fnd with
                                |(f_h::f_t) -> 
                                               let  wjwkd =interp_d wjwkd f_h in
                                               (f f_t wjwkd)
                                |[] -> interp_e wjwkd Store.empty expr
                                
                        in        
                        f fund FEnv.empty


       

