let rec sum n m f =
        if n = m+1 then 0
        else (f n) + (sum (n+1) m f)
