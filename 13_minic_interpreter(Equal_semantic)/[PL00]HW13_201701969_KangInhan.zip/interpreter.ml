module F = Format

(* practice & homework *)
let rec interp_e (e : Ast.expr) (s : Store.t) : Store.value = 
        match e with
        | Num i -> Store.NumV i
        | Bool i -> Store.BoolV i 
        | Var i -> Store.find i s
        | Add (exp1,exp2) -> let expr1 = interp_e exp1 s in
                                let expr2 = interp_e exp2 s in
                                begin
                                match expr1,expr2 with
                                | (Store.NumV e1, Store.NumV e2) -> Store.NumV (e1 + e2)
                                | _,_ -> failwith (Format.asprintf "Invalid addition: %a + %a" Ast.pp_e exp1 Ast.pp_e exp2)
                                end
        | Sub (exp1,exp2) -> let expr1 = interp_e exp1 s in
                                let expr2 = interp_e exp2 s in
                                begin
                                match expr1,expr2 with
                                | (Store.NumV e1, Store.NumV e2) -> Store.NumV (e1 - e2)
                                | _,_ -> failwith (Format.asprintf "Invalid subtraction: %a - %a" Ast.pp_e exp1 Ast.pp_e exp2)
                                end
        | Lt (exp1,exp2) -> begin
                                match (interp_e exp1 s), (interp_e exp2 s) with
                                | Store.NumV a, Store.NumV b -> if a < b then Store.BoolV true else Store.BoolV false
                                | _,_ -> failwith (Format.asprintf "Invalid less-than: %a, %a" Ast.pp_e exp1 Ast.pp_e exp2)
                                end

        |Gt (exp1,exp2) -> begin
                                match (interp_e exp1 s), (interp_e exp2 s) with
                                |Store.NumV a, Store.NumV b -> if a > b then Store.BoolV true else Store.BoolV false
                                | _,_ -> failwith (Format.asprintf "Invalid greater-than: %a, %a" Ast.pp_e exp1 Ast.pp_e exp2)
        end
        |Eq (exp1,exp2) -> begin
                                match (interp_e exp1 s), (interp_e exp2 s)  with
                                |Store.NumV a ,Store.NumV b -> if a = b then Store.BoolV true else Store.BoolV false
                                | _,_ -> failwith (Format.asprintf "Invalid equal-to: %a, %a" Ast.pp_e exp1 Ast.pp_e exp2)
        end
        |And (exp1,exp2) -> begin
                                match (interp_e exp1 s), (interp_e exp2 s) with
                                |Store.BoolV a, Store.BoolV b -> if (a = true && b = true) then Store.BoolV true else Store.BoolV false
                                | _,_ -> failwith (Format.asprintf "Invalid logical-and: %a, %a" Ast.pp_e exp1 Ast.pp_e exp2)
                             end
        |Or (exp1,exp2) -> begin
                                match (interp_e exp1 s), (interp_e exp2 s) with
                                |Store.BoolV a ,Store.BoolV b -> if (a = false && b = false) then Store.BoolV false else Store.BoolV true
                                | _,_ -> failwith (Format.asprintf "Invalid logical-or: %a, %a" Ast.pp_e exp1 Ast.pp_e exp2)
        end

(* practice & homework *)
let rec interp_s (stmt : Ast.stmt) (s : Store.t) : Store.t = 
        match stmt with
        | AssignStmt(str,exp) -> let s = Store.insert str (interp_e exp s) s in
                                s
        | IfStmt (e,true_stmts,false_stmts_opt) ->
                begin
                        match false_stmts_opt with
                        | None-> if interp_e e s = BoolV true then 
                                begin
                                        let rec func stmts store =
                                                match stmts with
                                                |h::t -> func t (interp_s h store)
                                                |[] -> store
                                        in
                                        func true_stmts s
                                end
                                else if interp_e e s = BoolV false then s
                                else failwith (F.asprintf "Not a boolean: %a " Ast.pp_e e)
                        | Some false_stmts_opt ->  if interp_e e s = BoolV true then
                               begin
                                       let rec func stmts store =
                                              match stmts with
                                              |h::t -> func t (interp_s h store)
                                              |[] -> store
                                       in
                                       func true_stmts s
                               end
                        else if interp_e e s = BoolV false then
                               begin
                                       let rec func stmts store =
                                              match stmts with
                                              |h::t -> func t (interp_s h store)
                                              |[] -> store
                                       in
                                       func false_stmts_opt s
                               end
                        else failwith (F.asprintf "Not a boolean: %a " Ast.pp_e e)
        end

(* practice & homework *)
let interp (p : Ast.program) : Store.t =
        match p with
        |Program stmtlist ->
                        begin
                        let rec interp2 stmt s =                          
                                        match stmt with
                                        | h::t -> (interp2 t (interp_s h s))
                                        | [] -> s
                        in
                        interp2 stmtlist Store.empty
                        end

