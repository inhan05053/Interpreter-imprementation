module F = Format

(* practice *)
let rec interp (e : Ast.ae) : int = 
        match e with
        | Num e -> e
        | Add (a, b) -> interp a + interp b
        | Sub (c, d) -> interp c - interp d
        | Neg k -> (-1)* interp k 
