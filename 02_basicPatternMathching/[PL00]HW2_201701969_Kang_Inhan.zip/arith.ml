type unop = Neg
type binop = Add | Sub | Mul | Div
type exp = 
        | Constant of int
        | Unary of unop * exp
        | Binary of exp * binop *exp

let rec eval (x:exp) =
        match x with
        | Binary(a ,Add,c) -> (eval a) + (eval c)
        | Binary(a ,Sub,c) -> (eval a) - (eval c)
        | Binary(a ,Mul,c) -> (eval a) * (eval c)
        | Binary(a ,Div,c) -> (eval a) / (eval c)
        | Unary (Neg,b) -> (-1) * (eval b)
        | Constant k -> k
