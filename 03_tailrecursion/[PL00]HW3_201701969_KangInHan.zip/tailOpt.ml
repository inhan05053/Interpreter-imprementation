let split k =
        let rec splitIn k (aux1,aux2)=
                match k with
                | [] -> (List.rev aux1,List.rev aux2)
                | (s1,s2) :: t -> (splitIn t ((s1::aux1),(s2::aux2)))
        in
        splitIn k ([],[]) 



let combine lsta lstb = 
        let rec combinelst lista listb result=
                match lista,listb with 
                | ((h1::t1),(h2::t2)) -> (combinelst t1 t2 ((h1,h2)::result))
                | _,_ -> List.rev result
        in
        combinelst lsta lstb []


