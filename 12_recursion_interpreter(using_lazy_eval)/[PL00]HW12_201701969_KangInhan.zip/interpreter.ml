module F = Format

(* practice & homework *)
let rec interp_e (s : Store.t) (e : Ast.expr) : Store.value = 
        match e with
        | Num i -> Store.NumV i
        | Add (exp1,exp2) -> let expr1 = interp_e s exp1 in
                                let expr2 = interp_e s exp2 in
                                begin
                                match expr1,expr2 with
                                | (NumV e1, NumV e2) -> NumV (e1 + e2)
                                | _,_ -> failwith (Format.asprintf "Invalid addition: %a + %a" Ast.pp_e exp1 Ast.pp_e exp2)
                                end
        | Sub (exp1,exp2) -> let expr1 = interp_e s exp1 in
                                let expr2 = interp_e s exp2 in
                                begin
                                match expr1,expr2 with
                                | (NumV e1, NumV e2) -> NumV (e1 - e2)
                                | _,_ -> failwith (Format.asprintf "Invalid subtraction: %a - %a" Ast.pp_e exp1 Ast.pp_e exp2)
                                end
        | Id (str) -> begin     
                                let t = Store.find str s in
                                match t with
                                |Store.FreezedV(expr,s) -> (interp_e s expr)
                                | _ -> Store.find str s
                        end

        | LetIn (str,ex1,ex2) ->let e = (interp_e s ex1) in
                                let s = (Store.insert str e s) in
                                let k = (interp_e s ex2) in
                                k
        | Fun (str,exp) -> Store.ClosureV(str,exp,s)
        | App (ex1,ex2) -> let exp1 = (interp_e s ex1) in
                        begin
                        match exp1 with
                                | Store.ClosureV(str,exp,ss) ->
                                        let s = (Store.insert str (Store.FreezedV(ex2,s)) ss) in
                                        (interp_e s exp)
                                |_ ->failwith (Format.asprintf "Not a function: %a" Ast.pp_e ex1) 
                        end
        | Lt(exp1,exp2) -> begin
                        match (interp_e s exp1), (interp_e s exp2) with
                        | NumV a, NumV b-> if a < b then ClosureV("x",Fun("y",(Id "x")),s) else ClosureV("x",Fun("y",(Id "y")),s)
                        | _,_ -> failwith (Format.asprintf "Invalid less-than: %a < %a" Ast.pp_e exp1 Ast.pp_e exp2)
                        end
        | RLetIn(x,e1,e2) -> 
                        begin
                                match interp_e s e1 with
                                |ClosureV (x',e,s') ->
                                                let rec s'' = (x, (Store.ClosureV (x',e,s''))) :: s' in
                                                interp_e s'' e2
                                | _ -> failwith (Format.asprintf "Not a function: %a" Ast.pp_e e1)
                        end
                        


let interp (p : Ast.fvae) : Store.value =
        match p with
               |(Prog exp) -> (interp_e Store.empty exp)
